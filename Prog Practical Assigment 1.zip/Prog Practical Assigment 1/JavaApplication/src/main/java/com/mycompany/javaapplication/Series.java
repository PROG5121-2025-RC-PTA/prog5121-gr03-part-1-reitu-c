/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.javaapplication;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author RC_Student_lab
 */
public class Series {
     public final ArrayList<SeriesModel> seriesList;
    private final Scanner myScanner;
    private boolean exitRequested = false;
    
    public Series(Scanner myScanner) {
        this.seriesList = new ArrayList<>();
        this.myScanner = myScanner;
    }
    
    public void runMenuLoop() {
        while (!exitRequested) {
            printMenu();
            System.out.print("Please select an option (1-6): ");
            String choice = myScanner.nextLine().trim();
            
            switch (choice) {
                case "1":
                    CaptureSeries();
                    break;
                case "2":
                    SearchSeries();
                    break;
                case "3":
                    UpdateSeries();
                    break;
                case "4":
                    DeleteSeries();
                    break;
                case "5":
                    SeriesReport();
                    break;
                case "6":
                    ExitSeriesApplication();
                    break;
                default:
                    System.out.println("Invalid option. Please select 1-6");
                    break;
            }
            
            if (!exitRequested) {
                System.out.println(); //Blank line for readability
            }
        }
    }
    
    public void printMenu() {
        System.out.println("Please select one of the following menu options:");
        System.out.println();
        System.out.println("(1) Capture a new series");
        System.out.println("(2) Search for a series");
        System.out.println("(3) Update series age restrictions");
        System.out.println("(4) Delete a series");
        System.out.println("(5) Print series report - 2025");
        System.out.println("(6) Exit Application");
    }
    
    public void CaptureSeries() {
        System.out.println();
        System.out.println("CAPTURE A NEW SERIES");
        
        System.out.println("Enter the series id: ");
        String id = myScanner.nextLine().trim();
        
        //Check for duplicate IF
        if (findSeriesIndexById(id) !=-1) {
            System.out.println("A series with ID: " + id + "already exists");
            promptReturnToMenu();
            return;
        }
        
        System.out.print("Enter the series name: ");
        String name = myScanner.nextLine().trim();
        
        //Age validation: numeric between 2 and 18
        String age = "";
        while (true) {
            System.out.print("Enter the series age restriction: ");
            String inputAge = myScanner.nextLine().trim();
            if (!isInteger(inputAge)) {
                System.out.println("You have entered an incorrect series age!!!");
                System.out.println("Please re-enter the series age >>");
                continue;
            }
            int ageValue = Integer.parseInt(inputAge);
            if (ageValue < 2 || ageValue > 18) {
                System.out.println("You have entered an incorrect series age!!!");
                System.out.println("Please re-enter the series age >>");
                continue;
        }
            age = Integer.toString(ageValue);
            break;
        }
        
        //Number of episodes: validate numeric and positive
        String episodes = "";
        while (true) {
            System.out.println("Enter the number of episodes for " + name + ":");
            String inputEps = myScanner.nextLine().trim();
            if (!isInteger(inputEps)) {
                System.out.println("Please enter a valid numeric number of episodes");
                continue;
            }
            int epsValue = Integer.parseInt(inputEps);
            if (epsValue < 0) {
                System.out.println("Number of episodes cannot be negative. Please re-enter");
                continue;
            }
            episodes = Integer.toString(epsValue);
            break;
        }
        
        //Create and store the new SeriesModel
        SeriesModel sm = new SeriesModel(id, name, age, episodes);
        seriesList.add(sm);
        
        System.out.println("Series processed successfully!!!");
        promptReturnToMenu();
    }
    
    public void SearchSeries() {
        System.out.println();
        System.out.println("Enter the series id to search: ");
        String id = myScanner.nextLine().trim();
        
        int index = findSeriesIndexById(id);
        if (index == -1) {
            System.out.println("Series with Series Id: " + id + " was not found!");
            promptReturnToMenu();
            return;
        }
        
        SeriesModel sm = seriesList.get(index);
        System.out.println();
        System.out.println("SERIES ID: " + sm.SeriesId);
        System.out.println("SERIES NAME: " + sm.SeriesName);
        System.out.println("SERIES AGE RESTRICTION: " + sm.SeriesAge);
        System.out.println("SERIES NUMBER OF EPISODES: " + sm.SeriesNumberOfEpisodes);
        
        promptReturnToMenu();
    }
    
    public void UpdateSeries() {
        System.out.println();
        System.out.print("Enter the series id to update: ");
        String id = myScanner.nextLine().trim();
        
        int index = findSeriesIndexById(id);
        if (index == -1) {
            System.out.println("Series with Series Id: " + id + " was not found!");
            promptReturnToMenu();
            return;
        }
        
        SeriesModel sm = seriesList.get(index);
        
        System.out.println();
        System.out.println("Enter the series name: ");
        String newName = myScanner.nextLine().trim();
        if (!newName.isEmpty()) {
            sm.SeriesName = newName;
        }
        
        //Age validation: numeric and between 2 and 18
        while (true) {
            System.out.print("Enter the age restriction: ");
            String inputAge = myScanner.nextLine().trim();
            if (!isInteger(inputAge)) {
                System.out.println("You have entered an incorrect series age!!!");
                System.out.println("Please re-enter series age >>");
                continue;
            }
            
            int ageValue = Integer.parseInt(inputAge);
            if (ageValue < 2 || ageValue > 18) {
                System.out.println("You have entered an incorrect series age!!!");
                System.out.println("Please re-enter series age >>");
                continue;
            }
            sm.SeriesAge = Integer.toString(ageValue);
            break;
        }
        
        //Number of episodes
        while (true) {
            System.out.print("Enter the number of episodes: ");
            String inputEps = myScanner.nextLine().trim();
            if (!isInteger(inputEps)) {
                System.out.println("Please enter a valid numeric number of episodes");
            continue;
        }
        int epsValue = Integer.parseInt(inputEps);
        if (epsValue < 0) {
            System.out.println("Number of episodes cannot be negative. Please re-enter");
            continue;
        }
        sm.SeriesNumberOfEpisodes = Integer.toString(epsValue);
        break;
    }
        
        System.out.println("Series Updated successfully!");
        promptReturnToMenu();
    }
    
    public void DeleteSeries() {
        System.out.println();
        System.out.println("Enter the series id to delete: ");
        String id = myScanner.nextLine().trim();
        
        int index = findSeriesIndexById(id);
        if (index == -1) {
            System.out.println("Series with Series Id: " + id + " was not found!");
            promptReturnToMenu();
            return;
        }
        
        System.out.println("Are you sure you want to delete series " + id + " from the system? Yes (1) to delete");
        System.out.println(">");
        String confirm = myScanner.nextLine().trim();
        
        if ("1".equals(confirm)) {
            seriesList.remove(index);
            System.out.println("Series with Series Id: " + id + " was deleted!");
        }
        else {
            System.out.println("Delete cancelled");
        }
        
        promptReturnToMenu();
    }
    
    public void SeriesReport() {
        System.out.println();
        System.out.println("Series Report - 2025");
        System.out.println();
        
        if (seriesList.isEmpty()) {
            System.out.println("No series captured yet");
            promptReturnToMenu();
            return;
        }
        
        int counter = 1;
        for (SeriesModel sm : seriesList) {
            System.out.println("Series " + counter);
            System.out.println("SERIES ID : " + sm.SeriesId);
            System.out.println("SERIES NAME: " + sm.SeriesName);
            System.out.println("SERIES AGE RESTRICTION: " + sm.SeriesAge);
            System.out.println("NUMBER OF EPISODES: " + sm.SeriesNumberOfEpisodes);
            System.out.println();
            counter++;
        }
        
        promptReturnToMenu();
    }
    
    public void ExitSeriesApplication() {
            System.out.println("Exiting Application. Goodbye!");
            this.exitRequested = true;
    }
    
    private void promptReturnToMenu() {
        System.out.println("Enter (1) to launch menu or any other key to exit");
        System.out.println("> ");
        String input = myScanner.nextLine().trim();
        if (!"1".equals(input)) {
            this.exitRequested = true;
            System.out.println("Exiting Application. Goodbye!");
        }
    }
    
    //id series id to search for
    //index in arrayList or -1 if not found
    
    public int findSeriesIndexById(String id) {
        for (int i = 0; i < seriesList.size(); i++) {
            if (seriesList.get(i).SeriesId.equals(id)) {
                return i;
            }
        }
        return -1;
    }
    
    private boolean isInteger(String s) {
        if (s == null || s.length() == 0) return false;
        try {
            Integer.parseInt(s);
            return true;
        }
        catch (NumberFormatException ex) {
            return false;
        }
    }
    
    private void seedSampleData() {
        seriesList.add(new SeriesModel("101", "Extreme Sports", "12", "10"));
        seriesList.add(new SeriesModel("102", "Bargain Hunters", "10", "10"));
        seriesList.add(new SeriesModel("103", "Home Cooking", "10", "20"));
    }
    
}
