/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.javaapplication;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author RC_Student_lab1
 * 
 */
public class JavaApplication {

    public static void main(String[] args) {
        Scanner myScanner = new Scanner(System.in);
        
        System.out.println("LATEST SERIES - 2025");
        System.out.println("Enter (1) to launch menu or any other key to exit");
        System.out.println("> ");
        String launcher = myScanner.nextLine();
        
        if (!"1".equals(launcher)) {
            System.out.println("Exiting Application. Goodbye!");
            myScanner.close();
            return;
        }
        
        //Create the Series manager and launch the application menu loop
        Series seriesManager = new Series(myScanner);
        seriesManager.runMenuLoop();
        
        //Close scanner before exiting
        myScanner.close();
    }
}


