/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */


import com.mycompany.javaapplication.Series;
import com.mycompany.javaapplication.SeriesModel;
import java.util.Scanner;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author RC_Student_lab
 */
public class SeriesManagerTest {
    
    private Series seriesManager;
    private int initialSize;
    
    @BeforeEach
    public void setUp() {
        //We pass a dmmy Scanner since we won't use interactive input in test
        seriesManager = new Series(new Scanner(System.in));
        
        //Add some test data
        seriesManager.seriesList.add(new SeriesModel("101", "Extreme Sports", "12", "10"));
        seriesManager.seriesList.add(new SeriesModel("102", "Bargain Huntrs", "10", "10"));
        seriesManager.seriesList.add(new SeriesModel("103", "Home Cooking", "10", "20"));
        
    }
    
    @Test
    public void testFindSeriesById_Found() {
        int index = seriesManager.findSeriesIndexById("101");
        assertEquals(0, index, "Series with ID '101' should be at index 0");
    }

    @Test
    public void testFindSeriesIndexById_NotFound() {
        int index = seriesManager.findSeriesIndexById("999");
        assertEquals(0, index, "Series with ID '999' should not exist");
    }
    
    @Test
    public void testAddDeries() {
        int initialSize = seriesManager.seriesList.size();
        SeriesModel newSeries = new SeriesModel("104", "Nature World", "14", "12");
        seriesManager.seriesList.add(newSeries);
        
        assertEquals(initialSize + 1, seriesManager.seriesList.size());
        assertEquals("Nature World", seriesManager.seriesList.get(initialSize).SeriesName);
    }
    
    @Test
    public void testUpdateSeries() {
        SeriesModel sm = seriesManager.seriesList.get(0);
        sm.SeriesName = "Extreme Adventures";
        sm.SeriesAge = "15";
        sm.SeriesNumberOfEpisodes = "25";
        
        assertEquals("Extreme Adventures", sm.SeriesName);
        assertEquals("15", sm.SeriesAge);
        assertEquals("25", sm.SeriesNumberOfEpisodes);
    }
    
    @Test
    public void testDeleteSeries() {
        int intialSize = seriesManager.seriesList.size();
        seriesManager.seriesList.remove(0);
        
        assertEquals(initialSize - 1, seriesManager.seriesList.size());
        assertEquals("102", seriesManager.seriesList.get(0).SeriesId, "First element should now be ID 102");
    }
}
