/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.studentgradeanalyser;

import java.util.Scanner;


/**
 *
 * @author RC_Student_lab
 */
public class StudentGradeAnalyser {

    public static void main(String[] args) {
        
        Scanner myScanner = new Scanner(System.in);
        
        System.out.print("Enter the number of students: ");
        int studentCount = myScanner.nextInt();
        myScanner.nextLine(); //Consume newline
        
        Student[] students = new Student[studentCount];
        
        //input student details
        for (int i = 0; i < studentCount; i++) {
            System.out.print("Enter the name of the student" + (i + 1) + ": ");
            String name = myScanner.nextLine();
            
            System.out.print("Enter the number of subjects for " + name + ": ");
            int subjectCount = myScanner.nextInt();
            
            int[] marks = new int[subjectCount];
            for (int j = 0; j < subjectCount; j++) {
                System.out.println("Enter the marks for subject " + (j + 1 + ": "));
                marks[j] = myScanner.nextInt();
            }
            myScanner.nextLine(); //Consume newline
            
            students[i] = new Student(name, marks);
        }
        
        //Report
        System.out.println("===== Student Grade Report =====");
        for (Student s : students) {
            System.out.println("Student: " + s.getName());
            System.out.println("Average Mark : " + s.getAverage());
            System.out.println("Highest Mark : " + s.getHighest());
            System.out.println("Lowest Mark: " + s.getLowest());
            System.out.println("-------------------------------------------------------");
        }
        myScanner.close();
    }

    //Base class (Inheritance Example)
    static class Person {
        private String name; //Information hiding
        
        public Person(String name) {
            this.name = name;
        }
        
        //Getter
        public String getName() {
            return name;
        }
    }

    //Derived class
    static class Student extends Person {
        private int[] marks; //Advanced array
        
        //Constructor
        public Student(String name, int[] marks) {
            super(name); //Call parent constructor
            this.marks = marks;
        }
        
        //Getter
        public int[] getMarks() {
            return marks;
        }
        
        //Calculate average mark
        public double getAverage() {
            int sum = 0;
            for (int mark : marks) {
                sum += mark;
            }
            return (double) sum / marks.length;
        }
        
        //Get highest grade
        public int getHighest() {
            int max = marks[0];
            for (int mark : marks) {
                if (mark > max) {
                    max = mark;
                }
            }
            return max;
        }
        
        //Get lowest grade
        public int getLowest() {
            int min = marks[0];
            for (int mark : marks) {
            if (mark < min) {
                min = mark;
            }
        }
        return min;
    }
    }
}


