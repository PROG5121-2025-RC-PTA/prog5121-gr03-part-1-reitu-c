/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.studentgradeanalyser;

/**
 *
 * @author RC_Student_lab
 */
public class Student extends Person{
   private int[] marks; //Advanced array
        
        //Constructor
        public Student(String name, int[] marks) {
            super(name); //Call parent constructor
            this.marks = marks;
        }
        
        //Getter
        public int[] getMarks() {
            return marks;
        }
        
        //Calculate average mark
        public double getAverage() {
            int sum = 0;
            for (int mark : marks) {
                sum += mark;
            }
            return (double) sum / marks.length;
        }
        
        //Get highest grade
        public int getHighest() {
            int max = marks[0];
            for (int mark : marks) {
                if (mark > max) {
                    max = mark;
                }
            }
            return max;
        }
        
        //Get lowest grade
        public int getLowest() {
            int min = marks[0];
            for (int mark : marks) {
            if (mark < min) {
                min = mark;
            }
        }
        return min;
    }
}
