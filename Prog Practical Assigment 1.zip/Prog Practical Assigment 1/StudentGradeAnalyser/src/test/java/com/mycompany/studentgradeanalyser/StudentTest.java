/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.studentgradeanalyser;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author RC_Student_lab
 */
public class StudentTest {
    
    @Test
    public void testAverage() {
        int[] marks = {70, 80, 90, 100};
        Student s = new Student("Reitu", marks);
        assertEquals(90.0, s.getAverage(), 0.001);
    }
    
    @Test
    public void testHighest() {
        int[] marks = {50, 67, 75, 100};
        Student s = new Student("Khumo", marks);
        assertEquals(100, s.getHighest());
    }
    
    @Test
    public void testLowest() {
    int[] marks = {29, 45, 60, 30};
    Student s =new Student("Mama", marks);
    assertEquals(30, s.getLowest());
    }
}
