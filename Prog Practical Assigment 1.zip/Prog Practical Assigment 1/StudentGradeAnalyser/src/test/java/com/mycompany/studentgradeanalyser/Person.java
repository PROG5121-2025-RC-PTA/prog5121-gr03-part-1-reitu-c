/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.studentgradeanalyser;

/**
 *
 * @author RC_Student_lab
 */
public class Person {
    private String name; //Information hiding
        
        public Person(String name) {
            this.name = name;
        }
        
        //Getter
        public String getName() {
            return name;
        }
}
